﻿
/*namespace Game_Pikachu
{
    partial class Connect
    {
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Connect));
            this.txtIP = new System.Windows.Forms.TextBox();
            this.pbConnect = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbConnect)).BeginInit();
            this.SuspendLayout();
            // 
            // txtIP
            // 
            this.txtIP.Location = new System.Drawing.Point(277, 123);
            this.txtIP.Name = "txtIP";
            this.txtIP.Size = new System.Drawing.Size(233, 22);
            this.txtIP.TabIndex = 1;
            // 
            // pbConnect
            // 
            this.pbConnect.BackColor = System.Drawing.Color.Transparent;
            this.pbConnect.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbConnect.BackgroundImage")));
            this.pbConnect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbConnect.Location = new System.Drawing.Point(277, 172);
            this.pbConnect.Margin = new System.Windows.Forms.Padding(4);
            this.pbConnect.Name = "pbConnect";
            this.pbConnect.Size = new System.Drawing.Size(233, 67);
            this.pbConnect.TabIndex = 15;
            this.pbConnect.TabStop = false;
            this.pbConnect.Click += new System.EventHandler(this.pbConnect_Click);
            // 
            // Connect
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pbConnect);
            this.Controls.Add(this.txtIP);
            this.Name = "Connect";
            this.Text = "Connect";
            this.Shown += new System.EventHandler(this.Connect_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.pbConnect)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtIP;
        private System.Windows.Forms.PictureBox pbConnect;*/
 //   }
//}*/